// Nicholas Zaharescu
// nzahare1@umbc.edu

import java.util.Scanner;
import java.util.Random;

public class SecurePassword {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();

        // Ask for first and last name
        System.out.println("Enter your first name:");
        String firstName = input.nextLine();

        System.out.println("Enter your last name and press enter:");
        String lastName = input.nextLine();

        // Create random integer between 10 and 99
        int randomNum = rand.nextInt(90) + 10; // 10–99 inclusive

        // Build the password
        char lastLetterFirst = Character.toUpperCase(firstName.charAt(firstName.length() - 1));
        String firstThreeLast = lastName.substring(0, Math.min(3, lastName.length())).toLowerCase();

        String password = lastLetterFirst + String.valueOf(randomNum) + firstThreeLast;

        System.out.println("\nYour password is: " + password);

        // Use concat to add ****
        password = password.concat("****");
        System.out.println("Your password after using concat: " + password);

        // Reverse the password
        StringBuilder sb = new StringBuilder(password);
        sb.reverse();
        String reversedPassword = sb.toString();

        System.out.println("Your password after reverse: " + reversedPassword);

        input.close();
    }
}
